/** Automatically generated file. DO NOT MODIFY */
package parkingaid.lpg.com.parkingadd;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}